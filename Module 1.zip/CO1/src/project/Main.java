package project;

public class Main {
    public static void main(String[] args) {
        SupportHandler rep = new SupportRepresentative();
        SupportHandler manager = new Manager();
        SupportHandler director = new Director();

        rep.setNextHandler(manager);
        manager.setNextHandler(director);

        System.out.println("Testing support system:");

        rep.handleRequest(new SupportRequest("General inquiry", 1));
        rep.handleRequest(new SupportRequest("Account suspension appeal", 2));
        rep.handleRequest(new SupportRequest("Critical security breach", 3));
    }
}
