package project;

public class Manager extends SupportHandler {
    @Override
    public void handleRequest(SupportRequest request) {
        if (request.getPriority() <= 2) {
            System.out.println("Manager handling request: " + request.getMessage());
        } else {
            System.out.println("Manager escalating request...");
            super.handleRequest(request);
        }
    }
}