package project;

public class SupportRepresentative extends SupportHandler {
    @Override
    public void handleRequest(SupportRequest request) {
        if (request.getPriority() <= 1) {
            System.out.println("Support Representative handling request: " + request.getMessage());
        } else {
            System.out.println("Support Representative escalating request...");
            super.handleRequest(request);
        }
    }
}
