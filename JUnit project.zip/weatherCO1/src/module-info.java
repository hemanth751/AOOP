/**
 * 
 */
/**
 * 
 */
module weatherCO1 {
}