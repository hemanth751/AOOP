package weather;

import java.util.Date;

public class Weather {
    private String condition;
    private double temperature;
    private Date date;

    public Weather(String condition, double temperature, Date date) {
        this.condition = condition;
        this.temperature = temperature;
        this.date = date;
    }

    public String getCondition() {
        return condition;
    }

    public double getTemperature() {
        return temperature;
    }

    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        return date + " - " + condition + " - " + temperature + "°C";
    }
}