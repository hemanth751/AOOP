package weather;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class WeatherService {
    public Weather getCurrentWeather() {
        return new Weather("Sunny", 25.0, Calendar.getInstance().getTime());
    }

    public List<Weather> get7DayForecast() {
        List<Weather> forecast = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        String[] conditions = {"Sunny", "Cloudy", "Rainy", "Stormy", "Snowy", "Windy", "Foggy"};

        for (int i = 0; i < 7; i++) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            forecast.add(new Weather(conditions[i % conditions.length], 20 + Math.random() * 10, calendar.getTime()));
        }
        return forecast;
    }
}