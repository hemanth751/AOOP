package weather;

import java.util.List;

public class WeatherApp {
    public static void main(String[] args) {
        WeatherService service = new WeatherService();

        // Display current weather
        System.out.println("Current Weather:");
        System.out.println(service.getCurrentWeather());

        // Display 7-day forecast
        System.out.println("\n7-Day Forecast:");
        List<Weather> forecast = service.get7DayForecast();
        for (Weather w : forecast) {
            System.out.println(w);
        }
    }
}