package weather;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

class WeatherServiceTest {
    private WeatherService service;

    @BeforeEach
    void setUp() {
        service = new WeatherService();
    }

    @Test
    void testGetCurrentWeather() {
        Weather weather = service.getCurrentWeather();
        assertNotNull(weather);
        assertNotNull(weather.getCondition());
        assertTrue(weather.getTemperature() > -50 && weather.getTemperature() < 60);
    }

    @Test
    void testGet7DayForecast() {
        List<Weather> forecast = service.get7DayForecast();
        assertNotNull(forecast);
        assertEquals(7, forecast.size());
        for (Weather w : forecast) {
            assertNotNull(w.getCondition());
            assertTrue(w.getTemperature() > -50 && w.getTemperature() < 60);
        }
    }
}