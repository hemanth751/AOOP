package project;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

class SupportHandlerTest {
    private SupportHandler rep;
    private SupportHandler manager;
    private SupportHandler director;
    private ByteArrayOutputStream outputStream;

    @BeforeEach
    void setUp() {
        rep = new SupportRepresentative();
        manager = new Manager();
        director = new Director();

        rep.setNextHandler(manager);
        manager.setNextHandler(director);

        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    void testLowPriorityRequestHandledByRep() {
        rep.handleRequest(new SupportRequest("Password reset", 1));
        assertTrue(outputStream.toString().contains("Support Representative handling request: Password reset"));
    }

    @Test
    void testMediumPriorityRequestHandledByManager() {
        rep.handleRequest(new SupportRequest("Billing issue", 2));
        assertTrue(outputStream.toString().contains("Manager handling request: Billing issue"));
    }

    @Test
    void testHighPriorityRequestHandledByDirector() {
        rep.handleRequest(new SupportRequest("System outage", 3));
        assertTrue(outputStream.toString().contains("Director handling request: System outage"));
    }
}
