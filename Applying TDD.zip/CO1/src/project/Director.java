package project;

public class Director extends SupportHandler {
    @Override
    public void handleRequest(SupportRequest request) {
        System.out.println("Director handling request: " + request.getMessage());
    }
}