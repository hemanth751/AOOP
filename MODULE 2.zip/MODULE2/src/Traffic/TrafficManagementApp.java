package Traffic;

import java.util.Random;

public class TrafficManagementApp {
    public static void main(String[] args) {
        TrafficSignalManager manager = new TrafficSignalManager();

        // Adding traffic signals dynamically
        manager.addSignal("Main Street", "Red", 60);
        manager.addSignal("2nd Avenue", "Green", 45);
        manager.addSignal("Downtown", "Yellow", 10);

        // Display initial signals
        manager.displaySignals();

        // Simulating congestion and adjusting signals dynamically
        adjustTrafficSignals(manager);
        manager.displaySignals();
    }

    public static void adjustTrafficSignals(TrafficSignalManager manager) {
        Random rand = new Random();

        System.out.println("\n🚦 Adjusting Traffic Signals Based on Congestion...\n");

        // Randomly updating signals to simulate real-time congestion adjustments
        manager.updateSignal("Main Street", rand.nextBoolean() ? "Green" : "Red", 30 + rand.nextInt(30));
        manager.updateSignal("2nd Avenue", rand.nextBoolean() ? "Yellow" : "Green", 20 + rand.nextInt(40));
        manager.updateSignal("Downtown", rand.nextBoolean() ? "Red" : "Green", 15 + rand.nextInt(30));
    }
}