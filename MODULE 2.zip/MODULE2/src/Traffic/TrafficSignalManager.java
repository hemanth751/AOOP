package Traffic;

import java.util.HashMap;
import java.util.Map;

public class TrafficSignalManager {
    // Nested class representing a traffic signal
    public static class TrafficSignal {
        private String location;
        private String color;
        private int duration; // Duration in seconds

        public TrafficSignal(String location, String color, int duration) {
            this.location = location;
            this.color = color;
            this.duration = duration;
        }

        public void setColor(String color) { this.color = color; }
        public void setDuration(int duration) { this.duration = duration; }
        public String getLocation() { return location; }
        public String getColor() { return color; }
        public int getDuration() { return duration; }

        @Override
        public String toString() {
            return "Signal at " + location + " | Color: " + color + " | Duration: " + duration + "s";
        }
    }

    // HashMap to store multiple traffic signals dynamically
    private Map<String, TrafficSignal> signals = new HashMap<>();

    public void addSignal(String location, String color, int duration) {
        signals.put(location, new TrafficSignal(location, color, duration));
    }

    public void updateSignal(String location, String newColor, int newDuration) {
        if (signals.containsKey(location)) {
            TrafficSignal signal = signals.get(location);
            signal.setColor(newColor);
            signal.setDuration(newDuration);
        } else {
            System.out.println("🚨 Signal at " + location + " not found!");
        }
    }

    public void displaySignals() {
        System.out.println("\n🚦 Current Traffic Signals:");
        for (TrafficSignal signal : signals.values()) {
            System.out.println(signal);
        }
    }
}