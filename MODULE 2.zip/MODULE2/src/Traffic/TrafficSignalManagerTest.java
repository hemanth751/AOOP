package Traffic;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TrafficSignalManagerTest {
    private TrafficSignalManager manager;

    @BeforeEach
    void setUp() {
        manager = new TrafficSignalManager();
        manager.addSignal("Main Street", "Red", 60);
    }

    @Test
    void testUpdateSignal() {
        manager.updateSignal("Main Street", "Green", 45);
        TrafficSignalManager.TrafficSignal signal = manager.signals.get("Main Street");

        assertEquals("Green", signal.getColor());
        assertEquals(45, signal.getDuration());
    }

    @Test
    void testInvalidSignalUpdate() {
        manager.updateSignal("Unknown Road", "Yellow", 30);
        assertFalse(manager.signals.containsKey("Unknown Road"));
    }
}