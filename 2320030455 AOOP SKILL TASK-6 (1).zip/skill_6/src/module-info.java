/**
 * 
 */
/**
 * 
 */
module skill_6 {
}