package musicstreaming;

import java.util.Scanner;

public class MusicStreamingApp {
    
    // Adapter Pattern - Music Player Interface
    interface MusicPlayer {
        void play(String songName);
    }

    // Adapter Implementations
    static class LocalMusicPlayer implements MusicPlayer {
        @Override
        public void play(String songName) {
            System.out.println("Playing local file: " + songName);
        }
    }

    static class OnlineMusicPlayer implements MusicPlayer {
        @Override
        public void play(String songName) {
            System.out.println("Streaming online: " + songName);
        }
    }

    static class RadioPlayer implements MusicPlayer {
        @Override
        public void play(String stationName) {
            System.out.println("Tuning into radio station: " + stationName);
        }
    }

    // Bridge Pattern - Music Source
    abstract static class MusicSource {
        protected MusicPlayer musicPlayer;

        public MusicSource(MusicPlayer musicPlayer) {
            this.musicPlayer = musicPlayer;
        }

        public abstract void playMusic(String songName);
    }

    // Bridge Implementations
    static class LocalSource extends MusicSource {
        public LocalSource(MusicPlayer musicPlayer) {
            super(musicPlayer);
        }

        @Override
        public void playMusic(String songName) {
            System.out.println("Playing from Local Source...");
            musicPlayer.play(songName);
        }
    }

    static class OnlineSource extends MusicSource {
        public OnlineSource(MusicPlayer musicPlayer) {
            super(musicPlayer);
        }

        @Override
        public void playMusic(String songName) {
            System.out.println("Playing from Online Streaming Service...");
            musicPlayer.play(songName);
        }
    }

    static class RadioSource extends MusicSource {
        public RadioSource(MusicPlayer musicPlayer) {
            super(musicPlayer);
        }

        @Override
        public void playMusic(String stationName) {
            System.out.println("Playing from Radio...");
            musicPlayer.play(stationName);
        }
    }

    // Facade Pattern - Simplified Interface
    static class MusicFacade {
        private LocalSource localSource;
        private OnlineSource onlineSource;
        private RadioSource radioSource;

        public MusicFacade() {
            localSource = new LocalSource(new LocalMusicPlayer());
            onlineSource = new OnlineSource(new OnlineMusicPlayer());
            radioSource = new RadioSource(new RadioPlayer());
        }

        public void playLocalMusic(String songName) {
            localSource.playMusic(songName);
        }

        public void playOnlineMusic(String songName) {
            onlineSource.playMusic(songName);
        }

        public void playRadio(String stationName) {
            radioSource.playMusic(stationName);
        }
    }

    // Main method
    public static void main(String[] args) {
        MusicFacade musicFacade = new MusicFacade();
        Scanner scanner = new Scanner(System.in);

        System.out.println("🎵 Welcome to the Music Streaming App 🎵");
        System.out.println("Choose an option:");
        System.out.println("1. Play Local Music");
        System.out.println("2. Play Online Music");
        System.out.println("3. Play Radio");
        System.out.println("Enter your choice:");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter the song/station name:");
        String songName = scanner.nextLine();

        switch (choice) {
            case 1:
                musicFacade.playLocalMusic(songName);
                break;
            case 2:
                musicFacade.playOnlineMusic(songName);
                break;
            case 3:
                musicFacade.playRadio(songName);
                break;
            default:
                System.out.println("Invalid choice!");
        }

        scanner.close();
    }
}
