/**
 * 
 */
/**
 * 
 */
module musicstreaming {
}